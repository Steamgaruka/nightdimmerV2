package com.nightdimmer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var power: Switch
    private lateinit var warm: Switch
    private lateinit var seek: SeekBar
    private lateinit var percent: TextView
    private lateinit var permBtn: Button
    private var ignore = false

    private val prefs get() = getSharedPreferences("dim", MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(x: Int) = (x * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#121212"))
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }

        fun label(t: String, size: Float = 16f) = TextView(this).apply {
            text = t; textSize = size; setTextColor(Color.WHITE)
            setPadding(0, dp(12), 0, dp(4))
        }

        root.addView(label("🌙 หรี่จอ", 28f))
        root.addView(label("ลดแสงหน้าจอ ดูหนังกลางคืนสบายตา", 14f).apply {
            setTextColor(Color.LTGRAY)
        })

        permBtn = Button(this).apply {
            text = "อนุญาตให้แสดงทับแอปอื่น"
            setOnClickListener {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }
        root.addView(permBtn)

        power = Switch(this).apply {
            text = "เปิดใช้งาน"; textSize = 18f; setTextColor(Color.WHITE)
            setPadding(0, dp(20), 0, dp(20))
            setOnCheckedChangeListener { _, on ->
                if (ignore) return@setOnCheckedChangeListener
                if (on) {
                    if (Settings.canDrawOverlays(this@MainActivity)) {
                        OverlayService.start(this@MainActivity)
                    } else {
                        setChecked(false)
                    }
                } else {
                    OverlayService.stop(this@MainActivity)
                }
            }
        }
        root.addView(power)

        root.addView(label("ความมืด"))
        percent = TextView(this).apply {
            textSize = 32f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }
        root.addView(percent)

        seek = SeekBar(this).apply {
            max = 97
            progress = prefs.getInt("level", 50)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    percent.text = "$p%"
                    prefs.edit().putInt("level", p).apply()
                    if (fromUser && OverlayService.running) OverlayService.start(this@MainActivity)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        percent.text = "${seek.progress}%"
        root.addView(seek)

        warm = Switch(this).apply {
            text = "โทนอุ่น (ลดแสงสีฟ้า)"; textSize = 16f; setTextColor(Color.WHITE)
            setPadding(0, dp(24), 0, dp(12))
            isChecked = prefs.getBoolean("warm", false)
            setOnCheckedChangeListener { _, on ->
                prefs.edit().putBoolean("warm", on).apply()
                if (OverlayService.running) OverlayService.start(this@MainActivity)
            }
        }
        root.addView(warm)

        val hw = Switch(this).apply {
            text = "ลดไฟหน้าจอจริง (ทดลอง)"; textSize = 16f; setTextColor(Color.WHITE)
            setPadding(0, dp(12), 0, dp(12))
            isChecked = prefs.getBoolean("hw", false)
            setOnCheckedChangeListener { _, on ->
                prefs.edit().putBoolean("hw", on).apply()
                if (OverlayService.running) OverlayService.start(this@MainActivity)
            }
        }
        root.addView(hw)

        root.addView(label("เคล็ดลับ: เพิ่มไทล์ \"หรี่จอ\" ในแถบ Quick Settings เพื่อเปิด/ปิดด่วน", 13f).apply {
            setTextColor(Color.GRAY)
        })

        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        permBtn.visibility =
            if (Settings.canDrawOverlays(this)) android.view.View.GONE else android.view.View.VISIBLE
        ignore = true
        power.isChecked = OverlayService.running
        ignore = false
    }
}
